package challenge.price_file_format;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 *
 */
public class Solution1 
{
    public static void main( String[] args ) throws IOException
    {
        System.out.println( "Hello World!" );
        ArrayList<String> products = new ArrayList<>();
        
        String fileAdd = "C:/Himansu/Preparation_Workspace/price_file_format/data.csv";
        products.add("baby_powder");
        products.add("teddy_bear");
        
        //products.add("scissor");
        //products.add("bath_towel");
        
        List<BabyProducts> listOfBabyProducts = readFileIntoObject(fileAdd);
        System.out.println("List "+listOfBabyProducts.size());
        List<BabyProducts>  filtreList = serach(listOfBabyProducts , products);
       // System.out.println("filtreList "+filtreList.size());
        
        if(filtreList != null)
        {
        	//List<BabyProducts>  filtreList = serach(listOfBabyProducts , products);
            System.out.println(listOfBabyProducts.size());
            System.out.println(filtreList.size());
        
            for (int i = 0; i < filtreList.size(); i++)
            {
            	System.out.print(filtreList.get(i).getShop_ID());
            	System.out.print("  "+filtreList.get(i).getPrice()+"  ");
            	for (int j = 0; j < filtreList.get(i).getProduct_label().size(); j++) 
            	{
            		System.out.print("  "+filtreList.get(i).getProduct_label().get(j));
            	}
            	System.out.println();
            }
        
            BabyProducts result = calculate(filtreList);
            System.out.print(result.getShop_ID());
            System.out.println(" "+result.getPrice());
        }
        else
        {
        	System.out.println("NONE......");
        }
    }
    
    public static BabyProducts calculate(List<BabyProducts> filtreList)
    {
    	BabyProducts result = new BabyProducts();
    	List<BabyProducts> temp1 = new ArrayList<>();
    	List<BabyProducts> temp2 = new ArrayList<>();
    	
    	float val1 ;
    	float val2;
    	
    	for (int i = 0; i < filtreList.size(); i++)
    	{
    		if(i == 0)
    		{	
    			temp1.add(filtreList.get(0));
    		}
    		else
    		if(temp1.get(0).getShop_ID() == filtreList.get(i).getShop_ID())
    		{
    			temp1.add(filtreList.get(i));
    		}
    		else
    		{
    			temp2.add(filtreList.get(i));
    		}
		}
    	
    	
    	for (int i = 0; i < temp1.size(); i++) {
			System.out.println(temp1.get(i).getShop_ID());
			System.out.println(temp2.get(i).getShop_ID());
		}
    	
    	val1 = addPrice(temp1);
    	val2 = addPrice(temp2);
    	
    	System.out.println(val1);
    	System.out.println(val2);
    	
    	BabyProducts baby = new BabyProducts();
    	
    	if(val1 < val2)
    	{	 
    		baby.setShop_ID(temp1.get(0).getShop_ID());
    		baby.setPrice(val1);
    		return baby;
    	}
    	else
    	{
    		baby.setShop_ID(temp2.get(0).getShop_ID());
    		baby.setPrice(val2);
    		return baby;

    	}
    }
    
    public static float addPrice(List<BabyProducts> temp)
    {
     	float val1 = 0;
    	
    	for (int i = 0; i < temp.size(); i++) {
    		val1 = val1 + temp.get(i).getPrice();
    	}
    	return val1;
    }
    
    public static List<BabyProducts> serach(List<BabyProducts> listOfBabyProducts, ArrayList<String> products )
    {
    	//String [] products = {"baby_powder","teddy_bear"};
    	List<BabyProducts> listOfbabyProduct = new ArrayList<>();
    	for (int i = 0; i < listOfBabyProducts.size(); i++) 
    	{
    		BabyProducts tempbabyProduct = new BabyProducts();
    		List<String> tempList = new ArrayList<>();
    		tempbabyProduct.setShop_ID(listOfBabyProducts.get(i).getShop_ID());
    		tempbabyProduct.setPrice(listOfBabyProducts.get(i).getPrice());
        	System.out.print(listOfBabyProducts.get(i).getShop_ID());
        	System.out.print("  "+listOfBabyProducts.get(i).getPrice());
			for (int j = 0; j < listOfBabyProducts.get(i).getProduct_label().size(); j++)
			{
				System.out.print("  "+listOfBabyProducts.get(i).getProduct_label().get(j));
				for (int k = 0; k < products.size(); k++) 
				{
					System.out.println("products.get(k)  "+products.get(k));
					if (products.get(k).equals(listOfBabyProducts.get(i).getProduct_label().get(j)))
					{	
						tempList.add(products.get(k));
						tempbabyProduct.setProduct_label(tempList);
						listOfbabyProduct.add(tempbabyProduct);
					}
				}
				//System.out.println("listOfbabyProduct "+ listOfbabyProduct.size());
				//if(listOfbabyProduct.size() < 2)
					//System.out.println("Himansu .......  None");
			}
			System.out.println();
		}
    	System.out.println("listOfbabyProduct "+ listOfbabyProduct.size());
		if(listOfbabyProduct.size() < 3)
		{	
			System.out.println("Himansu .......  None");
			listOfbabyProduct=null;
			System.out.println("null "+listOfbabyProduct);
			return listOfbabyProduct;
		}
		System.out.println();
    	return listOfbabyProduct;
    	
    }
    
    public static List<BabyProducts> readFileIntoObject(String fileAdd) throws NumberFormatException, IOException
    {
    	List<BabyProducts> listOfBabyProducts = new ArrayList<BabyProducts>();
        BufferedReader br = new BufferedReader(new FileReader(new File(fileAdd)));
        String line;
        while((line = br.readLine()) != null )
        {
        	String [] entries = line.split(",");
        	BabyProducts babyProducts = new BabyProducts();
    		List<String> product_label = new ArrayList<String>();
        	for (int i = 0; i < entries.length; i++) {
        		//System.out.println("entries[i]) "+  i +" "+entries[i]);
        		if (i==0)
        			babyProducts.setShop_ID(Integer.parseInt(entries[0]));
        		else if(i==1)
        			babyProducts.setPrice(Float.parseFloat(entries[1]));
        		else 
        			product_label.add(entries[i]);
        		
			}
        	babyProducts.setProduct_label(product_label);
        	listOfBabyProducts.add(babyProducts);
        }
        return listOfBabyProducts;
    }
}


/*package challenge.price_file_format;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 *

public class Solution1 
{
    public static void main( String[] args ) throws IOException
    {
        System.out.println( "Hello World!" );
        //String file = 
        List<BabyProducts> listOfBabyProducts = readFileIntoObject();
        
        List<BabyProducts>  filtreList = serach(listOfBabyProducts);
        
        System.out.println(listOfBabyProducts.size());
        System.out.println(filtreList.size());
        
        //for (int i = 0; i < listOfBabyProducts.size(); i++) {
        	//System.out.print(listOfBabyProducts.get(i).getShop_ID());
        	//System.out.print("  "+listOfBabyProducts.get(i).getPrice()+"  ");
			//for (int j = 0; j < listOfBabyProducts.get(i).getProduct_label().size(); j++) {
				//System.out.print("  "+listOfBabyProducts.get(i).getProduct_label().get(j));
			//}
			//System.out.println();
		//}
        
        for (int i = 0; i < filtreList.size(); i++) {
        	System.out.print(filtreList.get(i).getShop_ID());
        	System.out.print("  "+filtreList.get(i).getPrice()+"  ");
			for (int j = 0; j < filtreList.get(i).getProduct_label().size(); j++) {
				System.out.print("  "+filtreList.get(i).getProduct_label().get(j));
			}
			System.out.println();
		}
        
        BabyProducts result = calculate(filtreList);
        System.out.print(result.getShop_ID());
        System.out.println(" "+result.getPrice());
    }
    
    public static BabyProducts calculate(List<BabyProducts> filtreList)
    {
    	BabyProducts result = new BabyProducts();
    	List<BabyProducts> temp1 = new ArrayList<>();
    	List<BabyProducts> temp2 = new ArrayList<>();
    	
    	float val1 ;
    	float val2;
    	
    	for (int i = 0; i < filtreList.size(); i++)
    	{
    		if(i == 0)
    		{	
    			temp1.add(filtreList.get(0));
    		}
    		else
    		if(temp1.get(0).getShop_ID() == filtreList.get(i).getShop_ID())
    		{
    			temp1.add(filtreList.get(i));
    		}
    		else
    		{
    			temp2.add(filtreList.get(i));
    		}
		}
    	
    	
    	for (int i = 0; i < temp1.size(); i++) {
			System.out.println(temp1.get(i).getShop_ID());
			System.out.println(temp2.get(i).getShop_ID());
		}
    	
    	val1 = addPrice(temp1);
    	val2 = addPrice(temp2);
    	
    	System.out.println(val1);
    	System.out.println(val2);
    	
    	BabyProducts baby = new BabyProducts();
    	
    	if(val1 < val2)
    	{	 
    		baby.setShop_ID(temp1.get(0).getShop_ID());
    		baby.setPrice(val1);
    		return baby;
    	}
    	else
    	{
    		baby.setShop_ID(temp2.get(0).getShop_ID());
    		baby.setPrice(val2);
    		return baby;

    	}
    }
    
    public static float addPrice(List<BabyProducts> temp)
    {
     	float val1 = 0;
    	
    	for (int i = 0; i < temp.size(); i++) {
    		val1 = val1 + temp.get(i).getPrice();
    	}
    	return val1;
    }
    
    public static List<BabyProducts> serach(List<BabyProducts> listOfBabyProducts)
    {
    	String [] products = {"baby_powder","teddy_bear"};
    	List<BabyProducts> listOfbabyProduct = new ArrayList<>();
    	for (int i = 0; i < listOfBabyProducts.size(); i++) 
    	{
    		BabyProducts tempbabyProduct = new BabyProducts();
    		List<String> tempList = new ArrayList<>();
    		tempbabyProduct.setShop_ID(listOfBabyProducts.get(i).getShop_ID());
    		tempbabyProduct.setPrice(listOfBabyProducts.get(i).getPrice());
        	System.out.print(listOfBabyProducts.get(i).getShop_ID());
        	System.out.print("  "+listOfBabyProducts.get(i).getPrice());
			for (int j = 0; j < listOfBabyProducts.get(i).getProduct_label().size(); j++)
			{
				System.out.print("  "+listOfBabyProducts.get(i).getProduct_label().get(j));
				for (int k = 0; k < products.length; k++) 
				{
					if (products[k].equals(listOfBabyProducts.get(i).getProduct_label().get(j)))
					{	
						tempList.add(products[k]);
						tempbabyProduct.setProduct_label(tempList);
						listOfbabyProduct.add(tempbabyProduct);
					}
				}
				if(listOfbabyProduct.size() < 2)
					System.out.println("None");
			}
			System.out.println();
		}
    	return listOfbabyProduct;
    	
    }
    
    public static List<BabyProducts> readFileIntoObject() throws NumberFormatException, IOException
    {
    	List<BabyProducts> listOfBabyProducts = new ArrayList<BabyProducts>();
        BufferedReader br = new BufferedReader(new FileReader(new File("C:/Himansu/Preparation_Workspace/price_file_format/data.csv")));
        String line;
        while((line = br.readLine()) != null )
        {
        	String [] entries = line.split(",");
        	BabyProducts babyProducts = new BabyProducts();
    		List<String> product_label = new ArrayList<String>();
        	for (int i = 0; i < entries.length; i++) {
        		//System.out.println("entries[i]) "+  i +" "+entries[i]);
        		if (i==0)
        			babyProducts.setShop_ID(Integer.parseInt(entries[0]));
        		else if(i==1)
        			babyProducts.setPrice(Float.parseFloat(entries[1]));
        		else 
        			product_label.add(entries[i]);
        		
			}
        	babyProducts.setProduct_label(product_label);
        	listOfBabyProducts.add(babyProducts);
        }
        return listOfBabyProducts;
    }
}
*/